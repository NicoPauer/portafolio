package musica;

public class GeneroMusical 
{
	
  private String nombre, ritmo;
  
  private String[] instrumentacion, artistas;
  
  private int BPM_MIN, BPM_MAX;
  
  public GeneroMusical(String n, String[] ins, String rit, String[] arts, int min, int max)
  {
	  nombre = n;
	  instrumentacion = ins;
	  ritmo = rit;
	  artistas = arts;
	  BPM_MIN = min;
	  BPM_MAX = max;
  }

public void establecerNombre(String n)
  {
    /**
     * <p>Establece el nombre del género.</p>	  
     */
	  nombre = n;
  }
  
  public void establecerInstrumentacion(String[] ins)
  {
    /**
     * <p>Establece la instrumentación del género.</p>	  
     */
	  instrumentacion = ins;
  }
  
  public void establecerArtistas(String[] arts)
  {
    /**
     * <p>Establece los principales artistas del género.</p>	  
     */
	  artistas = arts;
  }
  
  public void establecerRitmo(String rit)
  {
    /**
     * <p>Establece el ritmo del género.</p>	  
     */
	  ritmo = rit;
  }
  
  public void establecerBPM(int min, int max)
  {
    /**
     * <p>Establece el rango del BPM que tiene generalmente el género.</p>	  
     */
	  BPM_MIN = min;
	  BPM_MAX = max;
  }
  
  public void reproducir(String n)
  {
    /**
     * <p>Reproduce un ejemplo del género musical.</p>	  
     */
	  System.out.println("Reproduciendo ejemplo de " + nombre + ".");
  }
  
  public String obtenerNombre()
  {
    /**
     * <p>Obtiene el nombre del género.</p>	  
     */
	  return nombre;
  }
  
  public String obtenerRitmo()
  {
    /**
     * <p>Obtiene el ritmo del género.</p>	  
     */
	  return ritmo;
  }
  
  public String[] obtenerInstrumentacion()
  {
    /**
     * <p>Obtiene la instrumentación del género.</p>	  
     */
	  return instrumentacion;
  }
  
  public String[] obtenerArtistas()
  {
    /**
     * <p>Obtiene los principales artistas del género.</p>	  
     */
	  return artistas;
  }
  
  public String obtenerBPM()
  {
    /**
     * <p>Obtiene el rango del BPM que tiene el género.</p>	  
     */
	  return BPM_MIN + " a " + BPM_MAX + " BPM";
  }
  
  public static void main(String args[])
  {
	  
	  GeneroMusical r, h, c;
	  
	  String[] artistas1 = {"Queen", "La Beriso", "The Rolling Stones"};
	  String[] artistas2 = {"David Guetta", "Alesso", "Avicii"};
	  String[] artistas3 = {"Marama", "Rafaga", "Daniel Agostini"};
	  
	  String[] instrumentos1 = {"guitarra", "bajo", "bateria", "voz"};
	  String[] instrumentos2 = {"sintetizador", "caja de ritmos", "samples", "ocasionalmente voz"};
	  String[] instrumentos3 = {"guitarra", "bajo", "instrumentos de percusión", "voz", "acordeón"};
	  
	  r = new GeneroMusical("El Rock", instrumentos1, "alargado", artistas1, 120, 140);
	  h = new GeneroMusical("El House", instrumentos2, "four on the flour", artistas2, 115, 130);
	  c = new GeneroMusical("La Cumbia", instrumentos3, "sincopado", artistas3, 60, 120);
	  
	  r.reproducir("rock.mp3");
	  h.reproducir("house.mp3");
	  c.reproducir("cumbia.mp3");
	  
	  System.out.println("");
	  
	  GeneroMusical[] generos = {r, h, c};
	  
	  for (int i = 0; i < generos.length; i++)
	  {
		  System.out.print(generos[i].obtenerNombre() + " tiene un ritmo " + generos[i].obtenerRitmo() + " de " + generos[i].obtenerBPM() + " y usa ");
		  
		  for (int j = 0; j < generos[i].obtenerInstrumentacion().length; j++)
		  {
			  if ((j != generos[i].obtenerInstrumentacion().length - 1) || (j == generos[i].obtenerArtistas().length - 2))
			  {
				if (j != generos[i].obtenerInstrumentacion().length - 2)
				{
			      System.out.print(generos[i].obtenerInstrumentacion()[j] + ", ");
				}
				else
				{
					System.out.print(generos[i].obtenerInstrumentacion()[j]);	
				}
			  }
			  else
			  {
				  System.out.print(" y " + generos[i].obtenerInstrumentacion()[j]);
			  }
			 
		  }
		  
		  System.out.print(". Sus principales artistas son ");
		  
		  for (int k = 0; k < generos[i].obtenerArtistas().length; k++)
		  {
			  if ((k != generos[i].obtenerArtistas().length - 1) || (k == generos[i].obtenerArtistas().length - 2))
			  {
				  if (k != generos[i].obtenerArtistas().length - 2)
				  {
				     System.out.print(generos[i].obtenerArtistas()[k] + ", ");
				  }
				  else
				  {
					System.out.print(generos[i].obtenerArtistas()[k]);	
				  }
			  }
			  else
			  {
				  System.out.print(" y " + generos[i].obtenerArtistas()[k] + ".");
			  }
		  }
		 
		  System.out.println("");
	  }
	  
	     
  }
  
}
