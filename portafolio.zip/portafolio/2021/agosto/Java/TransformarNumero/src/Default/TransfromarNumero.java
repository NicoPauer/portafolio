package Default;

import java.util.*;
import java.util.Map.*;

public class TransfromarNumero 
{
	
  private static int numero;
  
  public static void main(String args[])
  {
	  
	  System.out.println("Ingrese número a transformar: ");
	  
	 
	  Scanner entrada = new Scanner(System.in);
	  
	  numero = entrada.nextInt();
	  
	  
	  String resultado = "";
	    
	  char[] cadena = String.valueOf(numero).toCharArray();
	  
	 
	  HashMap digito = new HashMap();
	  
	  digito.put("1", "4");
	  digito.put("2", "1");
	  digito.put("3", "5");
	  digito.put("4", "3");
	  digito.put("5", "2");
	  digito.put("6", "6");
	  digito.put("7", "7");
	  digito.put("8", "8");
	  digito.put("9", "9");
	  
	  for (int i = 0; i < cadena.length; i++)
	  { 
		  resultado = resultado + digito.get("" + cadena[i]);    
	  }
	  
      System.out.println(resultado);
		  
	  }
  
}
