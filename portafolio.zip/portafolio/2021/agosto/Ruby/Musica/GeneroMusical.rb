#!/snap/bin/ruby


class GeneroMusical

  def initialize(n, ins, rit, arts, min, max)
    @nombre = n
    @ritmo = rit
    @instrumentacion = ins
    @artistas = arts
    @BPM_MIN = min
    @BPM_MAX = max
  end

  def establecerNombre(n)
    # Establece el nombre del género
    @nombre = n
  end

  def establecerInstrumentacion(ins)
    # Establece la instrumentación del género
    @intrumentacion = ins
  end

  def establecerArtistas(ars)
    # Establece los principales artistas del género
    @artistas = ars
  end

  def establecerRitmo(rit)
    # Establece el ritmo del género
    @ritmo = rit
  end

  def establecerBPM(min, max)
    # Establece el rango del BPM que tiene el género
    @BPM_MIN = min
    @BPM_MAX = max
  end

  def reproducir(nombre)
    # Reproduce un ejemplo del género con un nombre de archivo en especifico
    puts "Reproduciendo un ejemplo: #{nombre}\n"
    `ffplay #{nombre}`
  end

  def obtenerNombre()
    # Devuelve el nombre del género
    return @nombre
  end

  def obtenerRitmo()
    # Devuelve el ritmo del género
    return @ritmo
  end

  def obtenerInstrumentacion()
    # Obtiene la instrumentación del género
    return @instrumentacion
  end

  def obtenerArtistas()
    # Obtiene los principales artistas del género
    return @artistas
  end

  def obtenerBPM()
    # Obtiene el rango del BPM que tiene el género
    return "#{@BPM_MIN} a #{@BPM_MAX} BPM"
  end

end

r = GeneroMusical.new("El Rock", ["guitarra", "bajo", "bateria", "voz"], "alargado", ["Queen", "La Beriso", "The Rolling Stones"], 120, 140)

r.reproducir("rock.mp3")

h = GeneroMusical.new("El House", ["sintetizador", "caja de ritmos", "samples", "ocasionalmente voz"], "four on the floor", ["David Guetta", "Alesso", "Avicii"], 115, 130)

h.reproducir("house.mp3")

c = GeneroMusical.new("La Cumbia", ["guitarra", "bajo", "instrumentos de percusión", "voz", "acordeón"], "sincopado", ["Marama", "Rafaga", "Daniel Agostini"], 60, 120)

c.reproducir("cumbia.mp3")

puts "\n"

generos = [r, h, c]

3.times do |i|

  puts "\n"
  
  print "#{generos[i].obtenerNombre()} tiene un ritmo #{generos[i].obtenerRitmo()} de #{generos[i].obtenerBPM()} y usa "
  
  (generos[i].obtenerInstrumentacion().length()).times do |j|
    if (j != generos[i].obtenerInstrumentacion().length() - 1) 
      then
       if (j != generos[i].obtenerInstrumentacion().length() - 2)
         then print "#{generos[i].obtenerInstrumentacion()[j]}, "
        else  print "#{generos[i].obtenerInstrumentacion()[j]}"
        end
    else
        print " y #{generos[i].obtenerInstrumentacion[j]}. "  
    end  
  end

  print "Sus principales artistas son "
  
  (generos[i].obtenerArtistas().length()).times do |j|
    if ((j != generos[i].obtenerArtistas().length() - 1) or (j == generos[i].obtenerArtistas().length() - 2))
      then 
        if (j != generos[i].obtenerArtistas().length() - 2)
         then print "#{generos[i].obtenerArtistas()[j]}, "
        else  print "#{generos[i].obtenerArtistas()[j]}"
        end
    else
      if (j == generos[i].obtenerArtistas().length() - 2)
        then print "#{generos[i].obtenerArtistas()[j]}"
      else
        if (i != 2)  
          then print " y #{generos[i].obtenerArtistas()[j]}. \n"
        else
          print " y #{generos[i].obtenerArtistas()[j]}.\n"
        end    
      end  
    end   
  end
end
