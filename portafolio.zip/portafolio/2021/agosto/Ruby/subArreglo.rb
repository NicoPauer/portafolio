#!/snap/bin/ruby

# NO FUNCIONA

def sumatoria(arreglo)
  # Calcula la sumatoria de elementos de un arreglo
  
  suma = arreglo[0]
  
  for i in (1..arreglo.lenght() - 1) do
    suma = suma + arreglo[i]
  end
    
end

def calcMaxMitad(arreglo, mitad)
  # Calcula la mitad máxima del arreglo
  
  centro = []
  
 

  for i in (2..arreglo.length() / 2) 
    centro[i] = arreglo[i]
  end

  return centro
  
end

def maximo(arreglo1, arreglo2, arreglo3)
  # Calcula el arreglo máximo entre 3 viendo la sumatoria de sus elementos
  
  sumatoria1 = sumatoria(arreglo1)
  sumatoria2 = sumatoria(arreglo2)
  sumatoria3 = sumatoria(arreglo3)
  
  if (sumatoria1 > sumatoria2)
    then 
      if (sumatoria1 > sumatoria3)
        then return sumatoria1
      else
        return sumatoria3
      end  
  else
    if (sumatoria2 > sumatoria3)
      then return sumatoria2
    else
      return sumatoria3
    end
  end   
              
end

def MaxArray(arreglo)
  
  derecha = []
  izquierda = []
  
  if (arreglo.length() == 1)
    then return arreglo
  else
  
    for i in (1..arreglo.length() / 2) do 
      izquierda[i] = arreglo[i]
    end
    
    for i in (arreglo.length() / 2 + 1..arreglo.length() - 1) do 
      derecha[i] = arreglo[i]
    end  
      
    max_izq = MaxArray(izquierda.delete_at(1))
    max_der = MaxArray(derecha.delete_at(1))
    max_centro = CalcMaxMitad(arreglo, arreglo.length() / 2)
    
    return maximo(max_izq, max_der, max_centro)
          
  end
     
end

lista = [-3, 1, -2, 2, -1, 2]

puts MaxArray(lista)
