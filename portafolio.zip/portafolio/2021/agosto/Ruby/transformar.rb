#!/snap/bin/ruby


dic = {"1" => "4", "2" => "1", "3" => "5", "4" => "3", "5" => "2"}

print "Ingrese numero: "

numero = gets.chomp

resultado = numero.gsub(Regexp.union(dic.keys), dic)

print "#{resultado}\n"
